// 本文件是自动生成, 请勿修改
import chart from '@/plugin/chart/stage-config'
import custom from '@/plugin/custom/stage-config'
import linCmsUi from '@/plugin/lin-cms-ui/stage-config'

const pluginsConfig = [
  chart,
  custom,
  linCmsUi,
]

export default pluginsConfig
