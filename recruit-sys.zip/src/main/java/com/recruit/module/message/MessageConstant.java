package com.recruit.module.message;

/**
 * websocket 模块常量
 */
//public class MessageConstant {
//    public static final String USER_KEY = "user";
//}
