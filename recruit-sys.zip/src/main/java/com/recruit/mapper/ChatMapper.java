package com.recruit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.recruit.model.ChatDO;

/**
 * @Param eval
 * @Time 2022/9/28 12:48
 */
public interface ChatMapper extends BaseMapper<ChatDO> {
}
